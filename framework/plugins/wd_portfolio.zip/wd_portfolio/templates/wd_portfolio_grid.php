<?php
/**
 * Shortcode: tvlgiao_wpdance_special_gird_list_blog
 */

if (!function_exists('tvlgiao_wpdance_special_gird_portfolio_function')) {
	function tvlgiao_wpdance_special_gird_portfolio_function($atts) {
		extract(shortcode_atts(array(
			'id_category'				=> '-1'
			,'number_blogs'				=> '12'
			,'style'					=> 'portfolio-style-1'
			,'sort'						=> 'term_id'
			,'order_by'					=> 'DESC'
			,'columns'					=> '1'
			,'gap'						=> '0px'
			,'excerpt_words'			=> '20'
			,'pagination_loadmore'		=> '1'
			,'number_loadmore'			=> '8'
			,'class'					=> ''

		), $atts));
		wp_reset_query();
		// New blog
		$args = array(  
			'post_type' 		=> 'portfolio',  
			'posts_per_page' 	=> $number_blogs,
			'orderby' 			=> $sort,
			'order'				=> $order_by,
			'paged' 			=> get_query_var('paged')
		);
		//Category
		if( $id_category != -1 ){
			$args['tax_query']= array(
					    	array(
							    	'taxonomy' 		=> 'wd-portfolio-category',
									'terms' 		=> $id_category,
									'field' 		=> 'term_id',
									'operator' 		=> 'IN'
								)
			   			);
		}
		//Most View Products
		$special_portfolio 		= new WP_Query( $args );
		$span_class 		= "col-sm-".(24/$columns);
		ob_start(); ?>
		<?php if( $special_portfolio->have_posts() ) :?>
			<div class="wd-wrapper-special-grid">
				<div class='wd-shortcode-special-grid-portfolio <?php esc_html_e($class); ?> <?php esc_html_e($style); ?>'>
					<div class="grid wd-portfolio-content <?php echo 'grid-item-'.esc_attr($gap); ?>">
						<?php while ( $special_portfolio->have_posts() ) : $special_portfolio->the_post(); global $post; ?>
							<?php
								$thumb = get_post_thumbnail_id($post->ID);
								//$thumburl = wp_get_attachment_image_src($thumb,'full');
								$thumburl = wp_get_attachment_image_src($thumb,'portfolio_image');
								$light_box_url = trim(WD_Portfolio::wd_portfolio_get_meta('wd-portfolio'));
								if( strlen( $light_box_url ) <= 0 ){
									$light_box_url = $thumburl[0];
								}
								$light_box_class = WD_Portfolio::wd_portfolio_get_filetype( $light_box_url );
							?>
							<div class="wd-wrap-content-item grid-item <?php echo esc_attr($span_class); ?>">
								<div class="wd-wrap-content-inner">
									<div class="wd-thumbnail-post">
										<a class="thumbnail" href="<?php the_permalink(); ?>">
											<?php the_post_thumbnail('portfolio_image'); ?>
										</a>
										<?php if($style == 'portfolio-style-2') : ?>
											<div class="hover-default thumb-image-hover">
												<div class="icons">
													<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
													<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
												</div>
											</div>
										<?php endif; ?>
									</div>
									<?php if($style == 'portfolio-style-1') : ?>
										<div class="wd-content-portfolio">
											<div class="wd-title-portfolio">
												<h2 class="wd-heading-title">
													<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
												</h2>
											</div>
											<div class="wd-category-portfolio">
												<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
												<?php echo ($post_categories); ?>
											</div>
											<div class="hover-default thumb-image-hover">
												<div class="icons">
													<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
													<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
												</div>
											</div>
										</div>
									<?php endif; ?>
									<?php if($style == 'portfolio-style-2') : ?>
										<div class="wd-content-portfolio">
											<div class="wd-title-portfolio">
												<h2 class="wd-heading-title">
													<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
												</h2>
											</div>
											<div class="wd-category-portfolio">
												<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
												<?php echo ($post_categories); ?>
											</div>
										</div>
									<?php endif; ?>
								</div>
							</div>
						<?php endwhile;   ?>	
					</div>		
				</div>
				<div class="clear"></div>
				<?php if($pagination_loadmore == "1") : ?>
					<div class="wd-pagination">
						<?php tvlgiao_wpdance_pagination(3, $special_portfolio) ?>
					</div>
				<?php endif; ?>
				<?php if($pagination_loadmore == "0") : ?>
					<div class="wd-loadmore">
						<div style="display: none;" id="show_image_loading">
							<img src="<?php echo SC_IMAGE.'/ajax-loader_image.gif';?>" alt="HTML5 Icon" style="height:15px;">
						</div>

						<div id="loadmore">
							<a href="#" class="button btn_loadmore_grid_portfolio"><?php _e('LOAD MORE','wpdance') ?></a>
						</div>
					</div>
					<div class="hidden data-ajax-value">
						<input type="text" value="<?php esc_html_e($number_loadmore); ?>" id="tvlgiao_blog_number_loadmore">
						<input type="text" value="<?php esc_html_e($id_category); ?>" id="tvlgiao_blog_id_category">	
						<input type="text" value="<?php esc_html_e($data_show); ?>" id="tvlgiao_blog_data_show">
						<input type="text" value="<?php esc_html_e($columns); ?>" id="tvlgiao_blog_columns">
						<input type="text" value="<?php esc_html_e($show_data_image_slider); ?>" id="tvlgiao_blog_show_data_image_slider">
						<input type="text" value="<?php esc_html_e($style); ?>" id="tvlgiao_blog_show_style">
					</div>					
				<?php endif; ?>
			</div>
		<?php endif;// End have post ?>
		<script type="text/javascript">
			jQuery(function() {					
				jQuery("a[rel^='wd_pretty_photo']").prettyPhoto({
					social_tools : false
					,theme: 'pp_woocommerce'
					,default_width: jQuery('body').innerWidth()/8*5
					,default_height: window.innerHeight - 30
				});
			});
		</script>	
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		wp_reset_postdata();
		return $content;
	}
}
add_shortcode('tvlgiao_wpdance_special_gird_portfolio', 'tvlgiao_wpdance_special_gird_portfolio_function');
?>