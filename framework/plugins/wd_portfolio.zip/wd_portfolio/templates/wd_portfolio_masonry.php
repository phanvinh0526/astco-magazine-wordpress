<?php
/**
 * Shortcode: tvlgiao_wpdance_portfolio_masonry
 */

if (!function_exists('tvlgiao_wpdance_portfolio_masonry_function')) {
	function tvlgiao_wpdance_portfolio_masonry_function($atts) {
		extract(shortcode_atts(array(
			'style'					=> 'portfolio-style-1',
			'number' 				=> '6',
			'layoutmode'			=> 'masonry',
			'random_width'			=> '1',
			'columns'				=> '1',
			'gap'					=> '0px',
			'pagination_loadmore'	=> '0',
			'number_loadmore'		=> '6',
			'class'					=> ''
		),$atts));
		wp_reset_postdata();
		$args = array(		
			'post_type' 				=> 'portfolio'
			,'posts_per_page' 			=> $number
			,'ignore_sticky_posts' 		=> 1
			,'paged' 					=> get_query_var('paged')
		);
		$posts = new WP_Query($args);
		$span_class    	= '';
		if($layoutmode == 'masonry'){
			$span_class = "col-sm-".(24/$columns);
		}
		
		$post_count = 0;
		$_grid 		= 'grid_'.mt_rand();
		ob_start(); ?>
		<?php if( $posts->have_posts() ) : ?>
			<div class='wd-shortcode-masonry-portfolio <?php echo esc_attr($class); ?> <?php echo esc_attr($style); ?>'>	
				<div class="grid <?php echo esc_attr($_grid); ?> masonry-content <?php echo 'grid-item-'.esc_attr($gap); ?>">
					<?php while ( $posts->have_posts() ) : $posts->the_post(); global $post; ?>
						<?php
							$thumb = get_post_thumbnail_id($post->ID);
							$thumburl = wp_get_attachment_image_src($thumb,'full');
							$light_box_url = trim(WD_Portfolio::wd_portfolio_get_meta('wd-portfolio'));
							if( strlen( $light_box_url ) <= 0 ){
								$light_box_url = $thumburl[0];
							}
							$light_box_class = WD_Portfolio::wd_portfolio_get_filetype( $light_box_url );
							if($layoutmode == 'packery' && $random_width ){
								$span_class = "style-width-".rand(1, 4);
							}
						?>
						<div class="wd-wrap-content-masonry grid-item <?php echo esc_attr($span_class); ?>">
							<div class="wd-wrap-content-inner">
								<div class="wd-thumbnail-post">
									<a class="thumbnail" href="<?php the_permalink(); ?>">
										<?php the_post_thumbnail('full'); ?>
									</a>
									<?php if($style == 'portfolio-style-2') : ?>
										<div class="hover-default thumb-image-hover">
											<div class="icons">
												<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
												<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
											</div>
										</div>
									<?php endif; ?>
								</div>
								<?php if($style == 'portfolio-style-1') : ?>
									<div class="wd-content-portfolio">
										<div class="wd-title-portfolio">
											<h2 class="wd-heading-title">
												<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
											</h2>
										</div>
										<div class="wd-category-portfolio">
											<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
											<?php echo ($post_categories); ?>
										</div>
										<div class="hover-default thumb-image-hover">
											<div class="icons">
												<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
												<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
											</div>
										</div>
									</div>
								<?php endif; ?>
								<?php if($style == 'portfolio-style-2') : ?>
									<div class="wd-content-portfolio">
										<div class="wd-title-portfolio">
											<h2 class="wd-heading-title">
												<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
											</h2>
										</div>
										<div class="wd-category-portfolio">
											<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
											<?php echo ($post_categories); ?>
										</div>
									</div>
								<?php endif; ?>
							</div>
						</div>
					<?php endwhile;   ?>	
				</div>
				<?php if($pagination_loadmore == '1') : ?> 
					<div class="wd-pagination">
						<?php tvlgiao_wpdance_pagination(3, $posts); ?>
					</div>
					<?php wp_reset_postdata(); ?>
				<?php endif; ?>
				<?php if($pagination_loadmore == '0') : ?> 
					<div class="wd-loadmore">
						<div style="display: none;" id="show_image_loading">
							<img src="<?php echo SC_IMAGE.'/ajax-loader_image.gif';?>" alt="HTML5 Icon" style="height:15px;">
						</div>
						<div class="load_more_masonry">
							<a class="button btn_loadmore_masonry_portfolio"><?php _e('LOAD MORE','wpdance') ?></a>
						</div>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<script type='text/javascript'>
			<?php if($pagination_loadmore == '0') : ?> 
				var ajaxUrl = "<?php echo admin_url('admin-ajax.php', null); ?>";
				jQuery( document ).ready( function($) {
					"use strict";
					$('#show_image_loading').css( "display", "none" );
					$(document).on ( 'click', '.btn_loadmore_masonry_portfolio', function( event ) {
						var _this 						= $(this);
						var select_content_item_parent  = $(this).parents('.wd-shortcode-masonry-portfolio');
						var select_content_item 		= select_content_item_parent.find('.grid');		
						var offset_begin 				= select_content_item.children().length;				
						var page = 1; // What page we are on.
						//var offset_begin = $('.grid .grid-item').length;
						var offset = offset_begin;
						//alert(offset);
						var posts_per_page 	= <?php echo esc_attr($number_loadmore); ?> ;
						var columns			= <?php echo esc_attr($columns); ?> ;
						var style			= "<?php echo esc_attr($style); ?>" ;
						var layoutmode		= "<?php echo esc_attr($layoutmode); ?>" ;
						var random_width	= <?php echo esc_attr($random_width); ?> ;

						$('#show_image_loading').css( "display", "block" );
						$( '.grid' ).find( '#wd_status' ).remove();
						jQuery.post(ajaxUrl , {
							action:"more_portfolio_masonry_ajax",
							offset: offset,
							posts_per_page: posts_per_page,
							columns: columns,
							style: style,
							layoutmode: layoutmode,
							random_width: random_width,
						}).success(function(posts){
							$("#show_image_loading").css( "display", "none" );
							var $newItems = jQuery(posts);
							select_content_item.append( $newItems ).isotope( 'addItems', $newItems );

							tvlgiao_wpdance_load_isotope();
						
							var $item = $('<div class="grid-item" id="remove-grid-item"></div>');
							select_content_item.append( $item ).isotope( 'addItems', $item );
							tvlgiao_wpdance_load_isotope();
							$( '.grid' ).find( '#remove-grid-item' ).remove();

							var wd_status = document.getElementById('wp_outline_have_post').value;				
							if(wd_status == 0){
								$(".load_more_masonry a").removeClass('btn_loadmore_masonry').addClass('btn_end_load_more_masonry').html('END OF POSTS');
							}
							setTimeout(
							function(){
							    tvlgiao_wpdance_load_isotope();
							}, 1000);						
						});
					});
				});

			<?php endif; ?>		
			jQuery(document).ready(function() {
				"use strict";
				tvlgiao_wpdance_load_isotope();
				setTimeout(
				function(){
				    tvlgiao_wpdance_load_isotope();
				}, 2000);
			});

			function tvlgiao_wpdance_load_isotope(){
				jQuery('.grid').isotope({
					itemSelector: '.grid-item',
					<?php if($layoutmode == 'packery') : ?>
						layoutMode: 'packery',			
					<?php endif; ?>
					<?php if($layoutmode == 'masonry') : ?>
						layoutMode: 'masonry',			
					<?php endif; ?>
				});
					
				jQuery('img').load(function(){
					jQuery('.grid').isotope({
						itemSelector: '.grid-item',
						<?php if($layoutmode == 'packery') : ?>
							layoutMode: 'packery',			
						<?php endif; ?>
						<?php if($layoutmode == 'masonry') : ?>
							layoutMode: 'masonry',			
						<?php endif; ?>		
					});
				});
			}					
		</script>
		<script type="text/javascript">
			jQuery(function() {					
				jQuery("a[rel^='wd_pretty_photo']").prettyPhoto({
					social_tools : false
					,theme: 'pp_woocommerce'
					,default_width: jQuery('body').innerWidth()/8*5
					,default_height: window.innerHeight - 30
				});
			});
		</script>			
		<?php
		$output = ob_get_contents();
		ob_end_clean();
		wp_reset_postdata();
		return $output;
	}
}
add_shortcode('tvlgiao_wpdance_portfolio_masonry', 'tvlgiao_wpdance_portfolio_masonry_function');
?>