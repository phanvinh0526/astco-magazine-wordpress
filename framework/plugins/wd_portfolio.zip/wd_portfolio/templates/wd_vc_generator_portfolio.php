<?php
# Visual Composer installed?
if (function_exists('visual_composer')) {
	if (!function_exists('wd_portfolio_vc_shortcodes')) {
		/**
		 * Add theme's custom shortcodes to Visual Composer
		 */
		function wd_portfolio_vc_shortcodes() {
			/****************************************************************************/
			/*							portfolio 	 									*/
			/****************************************************************************/
			global $post;
			$portfolio_category = array();
			$portfolio_category[esc_html__('All Category','wdoutline')] = -1;
			if( class_exists('WD_Portfolio')){
				//$categories = get_terms( 'wd-portfolio-category' );
				//print_r($categories);
/*				foreach ($categories as $category ) {
					$portfolio_category[$category->slug] = $category->term_id;
				}*/
			}
			// Infomation
			vc_map(array(
				'name' 				=> esc_html__("Portfolio Masonry", 'wpdance'),
				'base' 				=> 'tvlgiao_wpdance_portfolio_masonry',
				'description' 		=> esc_html__("Style masonry of portfolio", 'wpdance'),
				'category' 			=> esc_html__("WPDance", 'wpdance'),
				'params' => array(
					/*array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'Select Category', 'wdoutline' )
						,'param_name' 	=> 'id_category'
						,'admin_label' 	=> true
						,'value' 		=> $portfolio_category
						,'description' 	=> ''
					),*/
					array(
						'type' 			=> 'textfield'
						,'heading' 		=> esc_html__( 'ID Category', 'wdoutline' )
						,'description'	=> esc_html__("Insert ID Category. If you want get category by ID", 'wpdance')
						,'param_name' 	=> 'id_category'
						,'admin_label' 	=> true
						,'value' 		=> ''
					),
					array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'Style', 'wpdance' )
						,'param_name' 	=> 'style'
						,'admin_label' 	=> true
						,'value' 		=> array(
								'Style 1'	=> 'portfolio-style-1',
								'Style 2'	=> 'portfolio-style-2',
							)
						,'description' => ''
					),
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> esc_html__("Number Post", 'wpdance'),
						'description' 	=> esc_html__("number", 'wpdance'),
						'admin_label' 	=> true,
						'param_name' 	=> 'number',
						'value' 		=> '6'
					),
					array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'LayoutMode', 'wpdance' )
						,'param_name' 	=> 'layoutmode'
						,'admin_label' 	=> true
						,'value' 		=> array(
								'Masonry'	=> 'masonry',
								'Packery'	=> 'packery',
							)
						,'description' => ''
					),
					array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'Random Width Image', 'wpdance' )
						,'param_name' 	=> 'random_width'
						,'admin_label' 	=> true
						,'value' 		=> array(
								'Yes'	=> '1',
								'No'	=> '0',
							)
						,'description' => ''
						,'dependency'  	=> Array('element' => "layoutmode", 'value' => array('packery'))
					),
					array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'Columns', 'wpdance' )
						,'param_name' 	=> 'columns'
						,'admin_label' 	=> true
						,'value' 		=> array(
								'1 Columns'		=> '1'
								,'2 Columns'	=> '2'
								,'3 Columns'	=> '3'
								,'4 Columns'	=> '4'
								,'6 Columns'	=> '6'
							)
						,'description' => ''
						,'dependency'  	=> Array('element' => "layoutmode", 'value' => array('masonry'))
					),
					array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'Gap', 'wpdance' )
						,'param_name' 	=> 'gap'
						,'description' 	=> esc_html__("Select gap between grid elements", 'wpdance')
						,'admin_label' 	=> true
						,'value' 		=> array(
								'0 px'	=> '0px',
								'1 px'	=> '1px',
								'2 px'	=> '2px',
								'3 px'	=> '3px',
								'4 px'	=> '4px',
								'5 px'	=> '5px',
								'10 px'	=> '10px',
								'15 px'	=> '15px',
								'20 px'	=> '20px',
								'25 px'	=> '25px',
								'30 px'	=> '30px',
								'35 px'	=> '35px',
							)
						,'description' => ''
					),
					array(
						'type' 			=> 'dropdown'
						,'heading' 		=> esc_html__( 'Show Pagination Or Load More', 'wdoutline' )
						,'param_name' 	=> 'pagination_loadmore'
						,'admin_label' 	=> true
						,'value' 	=> array(
								'Load More'		=> '0',
								'Pagination'	=> '1',
								'No Show'		=> '2'
							)
						,'description' 	=> ''
					),
					array(
						"type" 			=> "textfield",
						"class" 		=> "",
						"heading" 		=> esc_html__("Number Post Load More", 'wdoutline'),
						"admin_label" 	=> true,
						"param_name" 	=> "number_loadmore",
						"value" 		=> '6',
						"description" 	=> "",
						'dependency'  	=> Array('element' => "pagination_loadmore", 'value' => array('0'))
					),			
					array(
						'type' 			=> 'textfield',
						'class' 		=> '',
						'heading' 		=> esc_html__("Extra class name", 'wpdance'),
						'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wpdance'),
						'admin_label' 	=> true,
						'param_name' 	=> 'class',
						'value' 		=> ''
					)
				)
			));

			vc_map(array(
					"name"				=> esc_html__("Special Gird Portfolio",'wpdance'),
					"base"				=> 'tvlgiao_wpdance_special_gird_portfolio',
					'description' 		=> esc_html__("Special Gird portfolio", 'wpdance'),
					"category"			=> esc_html__("WPDance",'wpdance'),
					"params"=>array(	
						/*array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Select Category', 'wdoutline' )
							,'param_name' 	=> 'id_category'
							,'admin_label' 	=> true
							,'value' 		=> $blog_category
							,'description' 	=> ''
						),*/
						array(
							'type' 			=> 'textfield'
							,'heading' 		=> esc_html__( 'ID Category', 'wdoutline' )
							,'description'	=> esc_html__("Insert ID Category. If you want get category by ID", 'wpdance')
							,'param_name' 	=> 'id_category'
							,'admin_label' 	=> true
							,'value' 		=> ''
						),
						array(
							'type'			=> 'textfield'
							,'heading' 		=> esc_html__( 'Number Of portfolio', 'wdoutline' )
							,'param_name' 	=> 'number_blogs'
							,'admin_label' 	=> true
							,'value' 		=> '12'
						)
						,array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Style', 'wpdance' )
							,'param_name' 	=> 'style'
							,'admin_label' 	=> true
							,'value' 		=> array(
									'Style 1'	=> 'portfolio-style-1',
									'Style 2'	=> 'portfolio-style-2',
								)
							,'description' => ''
						)
						,array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Sort By', 'wpdance' )
							,'param_name' 	=> 'sort'
							,'admin_label' 	=> true
							,'value' 		=> array(
									'Date'		=> 'date'
									,'Name'		=> 'name'
									,'Slug'		=> 'slug'
								)
							,'description' => ''
						)
						,array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Order By', 'wpdance' )
							,'param_name' 	=> 'order_by'
							,'admin_label' 	=> true
							,'value' 		=> array(
									'DESC'		=> 'DESC'
									,'ASC'		=> 'ASC'
								)
							,'description' => ''
						)
						,array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Columns', 'wpdance' )
							,'param_name' 	=> 'columns'
							,'admin_label' 	=> true
							,'value' 		=> array(
									'1 Columns'		=> '1'
									,'2 Columns'	=> '2'
									,'3 Columns'	=> '3'
									,'4 Columns'	=> '4'
								)
							,'description' => ''
						)
						,array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Gap', 'wpdance' )
							,'param_name' 	=> 'gap'
							,'description' 	=> esc_html__("Select gap between grid elements", 'wpdance')
							,'admin_label' 	=> true
							,'value' 		=> array(
									'0 px'	=> '0px',
									'1 px'	=> '1px',
									'2 px'	=> '2px',
									'3 px'	=> '3px',
									'4 px'	=> '4px',
									'5 px'	=> '5px',
									'10 px'	=> '10px',
									'15 px'	=> '15px',
									'20 px'	=> '20px',
									'25 px'	=> '25px',
									'30 px'	=> '30px',
									'35 px'	=> '35px',
								)
						)
						,array(
							'type' 			=> 'textfield'
							,'heading' 		=> esc_html__( 'Number of excerpt words', 'wdoutline' )
							,'param_name' 	=> 'excerpt_words'
							,'admin_label' 	=> true
							,'value' 		=> '20'
							,'description' 	=> ''
						)
						,array(
							'type' 			=> 'dropdown'
							,'heading' 		=> esc_html__( 'Show Pagination Or Load More', 'wdoutline' )
							,'param_name' 	=> 'pagination_loadmore'
							,'admin_label' 	=> true
							,'value' 	=> array(
									'Pagination'	=> '1'
									,'Load More'	=> '0'
									,'No Show'		=> '2'
								)
							,'description' 	=> ''
						)
						,array(
							"type" 			=> "textfield",
							"class" 		=> "",
							"heading" 		=> esc_html__("Number blogs Load More", 'wdoutline'),
							"admin_label" 	=> true,
							"param_name" 	=> "number_loadmore",
							"value" 		=> '8',
							"description" 	=> "",
							'dependency'  	=> Array('element' => "pagination_loadmore", 'value' => array('0'))
						)
						,array(
							'type' 			=> 'textfield',
							'class' 		=> '',
							'heading' 		=> esc_html__("Extra class name", 'woocommerce'),
							'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'woocommerce'),
							'admin_label' 	=> true,
							'param_name' 	=> 'class',
							'value' 		=> ''
						)
					)
				)
			);

		} // End Function Shortcode
	}
}
# add theme's custom shortcodes to Visual Composer
add_action('vc_before_init', 'wd_portfolio_vc_shortcodes');
?>