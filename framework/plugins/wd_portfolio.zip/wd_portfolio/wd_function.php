<?php
add_action( 'wp_enqueue_scripts', 'tvlgiao_wpdance_ajax_pagination_scripts_portfolio' );
function tvlgiao_wpdance_ajax_pagination_scripts_portfolio() {
 	global $wp_query;
 	
 	wp_enqueue_script( 'wd-ajax-portfolio-script', plugins_url( '/js/wd_loadmore_portfolio.js', __FILE__ ), array( 'jquery' ) );
 	wp_localize_script( 'wd-ajax-portfolio-script', 'portfolio_gird_ajax_object', array(
		'ajax_url_portfolio_gird' 	=> admin_url( 'admin-ajax.php' ),
		'query_vars'				=> json_encode( $wp_query->query )
	));
}

add_action( 'wp_ajax_load_more_portfolio_gird', 'load_more_portfolio_function_special_grid' );
add_action( 'wp_ajax_nopriv_load_more_portfolio_gird', 'load_more_portfolio_function_special_grid' );
function load_more_portfolio_function_special_grid() {
	$query_vars 		= json_decode( stripslashes( $_POST['query_vars'] ), true );
	$offset 			= isset($_REQUEST['offset'])?intval($_REQUEST['offset']):0;
	$posts_per_page 	= isset($_REQUEST['posts_per_page'])?intval($_REQUEST['posts_per_page']):8;
	$post_type 			= isset($_REQUEST['post_type'])?$_REQUEST['post_type']:'post';
	$id_category 		= isset($_REQUEST['category_id'])?$_REQUEST['category_id']:'post';
	$columns			= isset($_REQUEST['columns'])?$_REQUEST['columns']:'post';
	$style				= isset($_REQUEST['style'])?$_REQUEST['style']:'post';
	$span_class 		= "col-sm-".(24/$columns);
	wp_reset_query();
	// New blog
	$args = array(  
		'post_type' 		=> 'portfolio',  
		'posts_per_page' 	=> $posts_per_page,
		'offset' 			=> $offset
	);
	//Category
	if( $id_category != -1 ){
		$args['tax_query']= array(
				    	array(
						    	'taxonomy' 		=> 'wd-portfolio-category',
								'terms' 		=> $id_category,
								'field' 		=> 'term_id',
								'operator' 		=> 'IN'
							)
		   			);
	}
	$special_portfolio 		= new WP_Query( $args );
	if ( $special_portfolio->have_posts() ){
		while ( $special_portfolio->have_posts() ) : $special_portfolio->the_post();  ?>
			<?php
				$thumb = get_post_thumbnail_id($post->ID);
				$thumburl = wp_get_attachment_image_src($thumb,'full');
				//$thumburl = wp_get_attachment_image_src($thumb,'portfolio_image');
				$light_box_url = trim(WD_Portfolio::wd_portfolio_get_meta('wd-portfolio'));
				if( strlen( $light_box_url ) <= 0 ){
					$light_box_url = $thumburl[0];
				}
				$light_box_class = WD_Portfolio::wd_portfolio_get_filetype( $light_box_url );
			?>
			<div class="wd-wrap-content-item grid-item <?php echo esc_attr($span_class); ?>">
				<div class="wd-wrap-content-inner">
					<div class="wd-thumbnail-post">
						<a class="thumbnail" href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail('portfolio_image'); ?>
						</a>
						<?php if($style == 'portfolio-style-2') : ?>
							<div class="hover-default thumb-image-hover">
								<div class="icons">
									<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
									<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
								</div>
							</div>
						<?php endif; ?>
					</div>
					<?php if($style == 'portfolio-style-1') : ?>
						<div class="wd-content-portfolio">
							<div class="wd-title-portfolio">
								<h2 class="wd-heading-title">
									<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
								</h2>
							</div>
							<div class="wd-category-portfolio">
								<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
								<?php echo ($post_categories); ?>
							</div>
							<div class="hover-default thumb-image-hover">
								<div class="icons">
									<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
									<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<?php if($style == 'portfolio-style-2') : ?>
						<div class="wd-content-portfolio">
							<div class="wd-title-portfolio">
								<h2 class="wd-heading-title">
									<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
								</h2>
							</div>
							<div class="wd-category-portfolio">
								<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
								<?php echo ($post_categories); ?>
							</div>
							<div class="hover-default thumb-image-hover">
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endwhile;	
	}else{ ?>
	    <div id="wd_status" class="hidden">
	    	<input type="text" value="1" id="tvlgiao_have_post">
		</div> <?php
	} // Have Product
    die();	
}


// AJAX
add_action('wp_ajax_nopriv_more_portfolio_masonry_ajax', 'tvlgiao_wpdance_more_portfolio_masonry_ajax'); 
add_action('wp_ajax_more_portfolio_masonry_ajax', 'tvlgiao_wpdance_more_portfolio_masonry_ajax');

function tvlgiao_wpdance_more_portfolio_masonry_ajax(){
	global $wp_outline_wd_data;

	$offset 		= $_POST["offset"];
	$posts_per_page = $_POST["posts_per_page"];
	$columns 		= $_POST["columns"];
	$style 			= $_POST["style"];
	$layoutmode 	= $_POST["layoutmode"];
	$random_width 	= $_POST["random_width"];
	header("Content-Type: text/html");

	wp_reset_postdata();
	$args = array(		
		'post_type' 				=> 'portfolio'
		,'posts_per_page' 			=> $posts_per_page
		,'offset' 					=> $offset
		,'ignore_sticky_posts' 		=> 1
	);
	$posts = new WP_Query($args);
	$span_class = '';
	if($layoutmode == 'masonry'){
		$span_class = "col-sm-".(24/$columns);
	}
	if( $posts->have_posts() ) { ?>
		<?php $wd_have_post = 1; ?>
		<?php while ( $posts->have_posts() ) : $posts->the_post(); global $post; ?>
			<?php
				$thumb = get_post_thumbnail_id($post->ID);
				$thumburl = wp_get_attachment_image_src($thumb,'full');
				$light_box_url = trim(WD_Portfolio::wd_portfolio_get_meta('wd-portfolio'));
				if( strlen( $light_box_url ) <= 0 ){
					$light_box_url = $thumburl[0];
				}
				$light_box_class = WD_Portfolio::wd_portfolio_get_filetype( $light_box_url );
				if($layoutmode == 'packery' && $random_width ){
					$span_class = "style-width-".rand(1, 4);
				}
			?>
			<div class="wd-wrap-content-masonry grid-item <?php echo esc_attr($span_class); ?>">
				<div class="wd-wrap-content-inner">
					<div class="wd-thumbnail-post">
						<a class="thumbnail" href="<?php the_permalink(); ?>">
							<?php the_post_thumbnail('full'); ?>
						</a>
						<?php if($style == 'portfolio-style-2') : ?>
							<div class="hover-default thumb-image-hover">
								<div class="icons">
									<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
									<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
								</div>
							</div>
						<?php endif; ?>
					</div>
					<?php if($style == 'portfolio-style-1') : ?>
						<div class="wd-content-portfolio">
							<div class="wd-title-portfolio">
								<h2 class="wd-heading-title">
									<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
								</h2>
							</div>
							<div class="wd-category-portfolio">
								<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
								<?php echo ($post_categories); ?>
							</div>
							<div class="hover-default thumb-image-hover">
								<div class="icons">
									<a class="zoom-gallery wd_pretty_photo thumb-image <?php echo esc_attr($light_box_class); ?>" title="<?php _e("View Portfolio","wpdance"); ?>" rel="wd_pretty_photo['<?php echo $light_box_class;?>']" href="<?php echo esc_url($light_box_url);?>"><?php esc_html_e('Quick view','wpdance');?></a>
									<a class="link-gallery " title="<?php _e("View Details","wpdance");?>" href="<?php the_permalink() ; ?>"><?php esc_html_e('Read','wpdance');?></a>
								</div>
							</div>
						</div>
					<?php endif; ?>
					<?php if($style == 'portfolio-style-2') : ?>
						<div class="wd-content-portfolio">
							<div class="wd-title-portfolio">
								<h2 class="wd-heading-title">
									<a href="<?php the_permalink() ; ?>"><?php the_title(); ?></a>
								</h2>
							</div>
							<div class="wd-category-portfolio">
								<?php $post_categories = get_the_term_list( $post->ID, 'wd-portfolio-category', '', ' , ', '' ); ?>
								<?php echo ($post_categories); ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		<?php endwhile;   ?>
	<?php }else{ ?>
	<?php $wd_have_post = 0;?>
	<?php }; ?>
	<div id="wd_status" class="hidden">
		<input type="text" value="<?php echo esc_html( $wd_have_post); ?>" id="wp_outline_have_post">
	</div>
	<?php exit; ?>
	<?php die();	
} 

# create a single for post portfolio
if(!function_exists('single_portfolio_template')){
	function single_portfolio_template($single){
		global $post,$wp_query;
	
		if($post->post_type == 'portfolio'){
			if(file_exists(plugin_dir_path( __FILE__ ).'/single-portfolio.php')){
				return plugin_dir_path( __FILE__ ).'/single-portfolio.php';
			}
		}
		return $single;
	}
}
add_filter('single_template','single_portfolio_template');
?>