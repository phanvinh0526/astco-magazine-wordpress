<?php
/*
Plugin Name: WD ShortCode
Plugin URI: http://www.wpdance.com/
Description: Plugin ShortCode From WPDance Team
Author: Wpdance
Version: 1.0.0
Author URI: http://www.wpdance.com/
*/
class WD_Shortcode
{
	protected $arrShortcodes = array();
	protected $arrVisualcomposer = array();
	public function __construct(){
		$this->constant();
		add_action('wp_enqueue_scripts', array( $this, 'init_script' ));
		
		require_once plugin_dir_path( __FILE__ ).'wd_functions.php';
		
		$this->initArrShortcodes();
		$this->initArrRegisterVC();
		$this->initShortcodes();
		//Load VC
		if($this->tvlgiao_wpdance_checkPluginVC()){
			if ( ! defined( 'ABSPATH' ) ) { exit; }
			add_action("vc_before_init",array($this,'tvlgiao_wpdance_load_visual'));
		}
		
		add_action( 'admin_head' , array($this, 'add_google_tracking'), 9999);
		//Register post type HTML Block
		add_action('init',  array($this, 'tvlgiao_wpdance_bootstrap_htmlblock_init'));

	}

	protected function initArrShortcodes(){
		$this->arrShortcodes 		= array('wd_faq','wd_category_product','wd_category_by_name','wd_special_girl_list_product','wd_special_blog','wd_feature','wd_site_header','wd_information',
									 		'wd_user_links','wd_dropdowncart','wd_social_profiles','wd_feedburner_subscription','wd_pricing_table','wd_search_post','wd_recent_comment',
									 		'wd_banner_image','wd_quote','wd_testimonials','wd_feature_slider','wd_brand_slider','wd_count_icon','wd_girl_list_blog','wd_masonry_blog',
									 		'wd_products_special_slider');
	}

	protected function initArrRegisterVC(){
		$this->arrVisualcomposer 	= array('wd_vc_category_product','wd_vc_category_by_name','wd_vc_products_girl_list','wd_vc_site_header', 'wd_vc_quote',
										 	'wd_vc_search_blog', 'wd_vc_information', 'wd_vc_blog_special', 'wd_vc_recent_comment', 'wd_vc_feedburner_subscription', 
										 	'wd_vc_social_profiles', 'wd_vc_pricing_table', 'wd_vc_banner_image', 'wd_vc_count_icon', 'wd_vc_brand_slider', 'wd_vc_user_links',
										 	'wd_vc_dropdowncart', 'wd_vc_feature', 'wd_vc_feature_slider',  'wd_vc_testimonials','wd_vc_blog_girl_list','wd_vc_blog_masonry',
										 	'wd_vc_products_special_slider');
	}

	protected function initShortcodes(){
		foreach($this->arrShortcodes as $shortcode){
			if( file_exists(SC_SHORTCODE."/{$shortcode}.php") ){
				require_once SC_SHORTCODE."/{$shortcode}.php";
			}	
		}
	}

	public function init_script(){
		global $post;
   		
		wp_register_style( 'wd-shortcode-css', SC_CSS.'/wd_shortcode.css');
		wp_enqueue_style('wd-shortcode-css');
		wp_register_style('tooltip-skin-css', 	SC_CSS.'/tooltip_skin.css');
		wp_enqueue_style('tooltip-skin-css');


		wp_register_script( 'wd-shortcode-js', SC_JS.'/wd_shortcode.js',false,false,true);
		wp_enqueue_script('wd-shortcode-js');
		wp_register_script( 'bootstrap-js', 	SC_JS.'/bootstrap.js');
		wp_enqueue_script('bootstrap-js');
		wp_register_script( 'jquery-sky-carousel-js', 		SC_JS.'/jquery.sky.carousel-1.0.2.min.js');
		wp_enqueue_script('jquery-sky-carousel-js');	
	}
	
	protected function constant(){
		define('SC_BASE'		,  	plugins_url( '', __FILE__ ));
		define('SC_SHORTCODE'	, 	plugin_dir_path( __FILE__ ) . 'shortcode' );
		define('SC_VISUAL'		, 	plugin_dir_path( __FILE__ ) . 'visualcomposer' );
		define('SC_ASSET'		, 	SC_BASE  . '/assets'	);
		define('SC_JS'			, 	SC_ASSET . '/js'		);
		define('SC_CSS'			, 	SC_ASSET . '/css'		);
		define('SC_IMAGE'		, 	SC_ASSET . '/images'	);
	}
	protected function tvlgiao_wpdance_checkPluginVC(){
		$_active_vc = apply_filters('active_plugins',get_option('active_plugins'));
		if(in_array('js_composer/js_composer.php',$_active_vc)){
			return true;
		}else{
			return false;
		}
	}

	public function tvlgiao_wpdance_load_visual(){
		foreach ($this->arrVisualcomposer as $visual) {
			if( file_exists(SC_VISUAL."/{$visual}.php") ){
				require_once SC_VISUAL."/{$visual}.php";
			}
		}
    }

	public function tvlgiao_wpdance_bootstrap_htmlblock_init(){
		register_taxonomy( 'wpdance_category_html', 'book', array(
			'hierarchical'      => true,
			'labels'            => array(
				'name' 				=> esc_html__('Categories HTML', 'wpdance'),
				'singular_name' 	=> esc_html__('Categories HTML', 'wpdance'),
            	'new_item'          => esc_html__('Add New', 'wpdance' ),
            	'edit_item'         => esc_html__('Edit Post', 'wpdance' ),
            	'view_item'   		=> esc_html__('View Post', 'wpdance' ),
            	'add_new_item'      => esc_html__('Add New Category HTML', 'wpdance' ),
            	'menu_name'         => esc_html__( 'Categories HTML' , 'wpdance' ),
			),
			'show_ui'           	=> true,
			'show_admin_column' 	=> true,
			'query_var'         	=> true,
			'rewrite'           	=> array( 'slug' => 'wpdance_category_html' ),				
			'public'				=> true,
		));

		register_post_type('wpdance_html', array(
			'labels' => array(
				'name' 				=> esc_html__("HTML Blocks", 'wpdance'),
				'singular_name' 	=> esc_html__("HTML Block", 'wpdance'),
            	'new_item'          => esc_html__( 'Add New', 'wpdance' ),
            	'edit_item'         => esc_html__( 'Edit Post', 'wpdance' ),
            	'view_item'   		=> esc_html__( 'View Post', 'wpdance' )
			),
			'taxonomies' 			=> array('wpdance_category_html'),
			'public' 				=> true,
			'has_archive' 			=> false
		));
		
		add_theme_support('post-thumbnails');
		add_post_type_support( 'wpdance_html', 'thumbnail' );
		
		$term_header = term_exists( 'wpdance_header_layout', 'wpdance_category_html' );
		if ( $term_header == 0 && $term_header == null ) {
		    wp_insert_term( esc_html__('Header', 'wpdance') , 'wpdance_category_html', array(
		    	'description'		=> esc_html__('Layout Header','wpdance'),
		    	'slug' 				=> 'wpdance_header_layout'
				));
		}
		

		$term_footer = term_exists( 'wpdance_footer_layout', 'wpdance_category_html' );
		if ( $term_header == 0 && $term_header == null ) {
  			wp_insert_term( esc_html__('Footer', 'wpdance') , 'wpdance_category_html', array(
			    'description'		=> esc_html__('Layout Footer','wpdance'),
			    'slug' 				=> 'wpdance_footer_layout'
  			));
  		}		
	}

	function add_google_tracking(){
		?>
		<script>

		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){

		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),

		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)

		  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');



		  ga('create', 'UA-55571446-5', 'auto');

		  ga('require', 'displayfeatures');

		  ga('send', 'pageview');

		</script>
		<?php
	}
}	

$_wd_shortcode = new WD_Shortcode;

?>