<?php
	/****************************************************************************/
	/*						FEATURE BY WOOCOMERCE								*/
	/****************************************************************************/
	if( post_type_exists('feature') || class_exists('Woothemes_Features') ){				
		/*$feature_category = array();
		$feature_category[esc_html__('Select Category','wpdance')] = -1;
		$categories = 	get_terms( 'feature-category', 
									array('hide_empty' 	=> 0)
						);
		foreach ($categories as $category ) {		
			$feature_category[$category->slug] = $category->term_id;
		}
		wp_reset_postdata();*/
		vc_map( array(
			'name' 			=> esc_html__( 'Feature By Woo Slider', 'wpdance' )
			,'base' 		=> 'tvlgiao_wpdance_feature_slider'
			,'category' 	=> esc_html__( 'WD Content', 'wpdance')
			,'params' 		=> array(
				/*array(
					'type' 				=> 'dropdown'
					,'heading' 			=> esc_html__( 'Select Category', 'wpdance' )
					,'param_name' 		=> 'id_category'
					,'admin_label' 		=> true
					,'value' 			=> $feature_category
					,'description' 		=> ''
				),*/
				array(
					'type' 				=> 'textfield',
					'class' 			=> '',
					'heading' 			=> esc_html__("Number Feature", 'wpdance'),
					'description'		=> esc_html__("Number feature", 'wpdance'),
					'admin_label' 		=> true,
					'param_name' 		=> 'number',
					'value' 			=> ''
				)
				,array(
					'type' 				=> 'dropdown'
					,'heading' 			=> esc_html__( 'Show feature title', 'wpdance' )
					,'param_name' 		=> 'title'
					,'admin_label' 		=> true
					,'value' 			=> array(
							'Yes'	=> 'yes'
							,'No'	=> 'no'
						)
					,'description' 		=> ''
				)
				,array(
					'type' 				=> 'dropdown'
					,'heading' 			=> esc_html__( 'Show excerpt', 'wpdance' )
					,'param_name' 		=> 'excerpt'
					,'admin_label' 		=> true
					,'value' 			=> array(
							'Yes'	=> 'yes'
							,'No'	=> 'no'
						)
					,'description' 		=> ''
				)
				,array(
					'type' 				=> 'dropdown'
					,'heading' 			=> esc_html__( 'Show Readmore', 'wpdance' )
					,'param_name' 		=> 'readmore'
					,'admin_label' 		=> true
					,'value' 			=> array(
							'Yes'	=> 'yes'
							,'No'	=> 'no'
						)
					,'description' 		=> ''
				)
				,array(
					'type' 				=> 'textfield',
					'class' 			=> '',
					'heading' 			=> esc_html__("Extra class name", 'wpdance'),
					'description'		=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wpdance'),
					'admin_label' 		=> true,
					'param_name' 		=> 'class',
					'value' 			=> ''
				)
			)
		));

	}// End Feature By WooCommerce
?>