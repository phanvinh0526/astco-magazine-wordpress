<?php
	# Add shortcode Site Header
	vc_map(array(
		'name' 				=> esc_html__("Site Header", 'wpdance'),
		'base' 				=> 'tvlgiao_wpdance_site_header',
		'description' 		=> esc_html__("Display site info (title, tagline, logo...) on the header", 'wpdance'),
		'category' 			=> esc_html__("WPDance", 'wpdance'),
		'params' => array(
			array(
				"type" 			=> "attach_image",
				"class" 		=> "",
				"heading" 		=> esc_html__("Logo Image", 'wpdance'),
				"description" 	=> esc_html__("If you do not want the default logo, you add another logo here", 'wpdance'),
				"param_name" 	=> "custom_logo_url",
				"value" 		=> "",
			),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wpdance'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wpdance'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
?>