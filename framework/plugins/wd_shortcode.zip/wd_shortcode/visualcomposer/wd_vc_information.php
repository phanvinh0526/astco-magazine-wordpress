<?php
	// Infomation
	vc_map(array(
		'name' 				=> esc_html__("Information", 'wpdance'),
		'base' 				=> 'tvlgiao_wpdance_information',
		'description' 		=> esc_html__("Display info contact, email, telephone", 'wpdance'),
		'category' 			=> esc_html__("WPDance", 'wpdance'),
		'params' => array(
			array(
				"type" 			=> "dropdown",
				"class" 		=> "",
				"heading" 		=> esc_html__("Style", 'wpdance'),
				"admin_label" 	=> true,
				"param_name" 	=> "style",
				"value" => array(
						'Style 1' => 'style-1',
						'Style 2' => 'style-2'
					),
				"description" 	=> ""
			),
			array(
				'type' 			=> 'iconpicker',
				'heading' 		=> esc_html__( 'Icon', 'wpdance' ),
				'param_name' 	=> 'icon_fontawesome',
				'value' 		=> 'fa fa-adjust', 	
				'settings' 		=> array(
					'emptyIcon' 	=> false,
					'iconsPerPage' 	=> 4000,
					),
				'description' 	=> esc_html__( 'Select icon from library.', 'wpdance' )
			),
	        array(
	            "type" 			=> "textarea_html",
	            "holder" 		=> "div",
	            "class" 		=> "",
	            "heading" 		=> esc_html__( "Content", 'wpdance' ),
	            "param_name" 	=> "content",
	            "value" 		=> esc_html__( "I am test text block. Click edit button to change this text.", 'wpdance' ),
	            "description" 	=> esc_html__( "Enter your content.", 'wpdance' )
	        ),
			array(
				'type' 			=> 'textfield',
				'class' 		=> '',
				'heading' 		=> esc_html__("Extra class name", 'wpdance'),
				'description'	=> esc_html__("Style particular content element differently - add a class name and refer to it in custom CSS.", 'wpdance'),
				'admin_label' 	=> true,
				'param_name' 	=> 'class',
				'value' 		=> ''
			)
		)
	));
?>