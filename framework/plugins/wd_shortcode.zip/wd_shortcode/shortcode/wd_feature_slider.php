<?php
/**
 * Shortcode: tvlgiao_wpdance_feature_slider
 */
if(!function_exists('tvlgiao_wpdance_feature_slider_function')){
	function tvlgiao_wpdance_feature_slider_function($atts,$content){
		extract(shortcode_atts(array(
			'number'				=> '5'
			,'title'				=>	'yes'
			,'excerpt'				=>	'yes'
			,'readmore'				=> 	'yes'
			,'class'				=>	''
		),$atts));
		
		$title 		= strcmp('yes',$title) 		== 0 ? 1 : 0; 
		$excerpt 	= strcmp('yes',$excerpt) 	== 0 ? 1 : 0;
		$readmore 	= strcmp('yes',$readmore) 	== 0 ? 1 : 0;
		$args = array(
			'post_type' 	=> 'feature',
			'posts_per_page'=>	$number,
		);
		$feature_post = new WP_Query( $args );		
		
		if ( $feature_post->have_posts() ) {
			$num_post =  $feature_post->post_count;
			$random_id = 'wd_feature_woo_'.mt_rand();
			ob_start(); ?>
			<div id="<?php echo esc_attr($random_id); ?>" class="wd-feature-shortcode <?php echo esc_attr($class); ?>">
				<ul class="slides">
				<?php while( $feature_post->have_posts() ) : $feature_post->the_post(); global $post; ?>
					<?php if(has_post_thumbnail()){ ?>
						<li  data-thumb="<?php echo esc_url(the_post_thumbnail_url('full'));?>">
							<a href="<?php echo esc_url(the_post_thumbnail_url('full'));?>" data-rel="prettyPhoto[product-gallery]">
								<?php the_post_thumbnail('full',array('class' => 'thumbnail-effect-1', 'title'=>get_the_title())); ?>
							</a>
						</li>				 
					<?php } ?>
				<?php endwhile; ?>
				</ul>
			</div>
			<script type="text/javascript">
				if(jQuery('#<?php echo esc_attr($random_id); ?>').length >0 ){
					jQuery('#<?php echo esc_attr($random_id); ?>').each(function(){
						var _auto = true;
						var _nav = true;
						var _pagi = true;
						jQuery(this).flexslider({
							animation: "slide"
							,controlNav: _pagi
							,directionNav: _nav
							,slideshow: _auto
							,controlNav: "thumbnails"
						});
					});
				}
			</script>
		<?php } //endif 
		$output = ob_get_contents();
		ob_end_clean();
		wp_reset_query();
		return $output;
	}
}
add_shortcode('tvlgiao_wpdance_feature_slider','tvlgiao_wpdance_feature_slider_function');
?>