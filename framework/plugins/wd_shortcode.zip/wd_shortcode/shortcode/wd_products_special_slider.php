<?php
/**
 * Shortcode: tvlgiao_wpdance_special_products_slider
 */

if (!function_exists('tvlgiao_wpdance_special_products_slider_function')) {
	function tvlgiao_wpdance_special_products_slider_function($atts) {
		extract(shortcode_atts(array(
			'title'					=> ""
			,'id_category'			=> '-1'
			,'data_show'			=> 'recent_product'
			,'number_products'		=> '12'
			,'sort'					=> 'term_id'
			,'order_by'				=> 'DESC'
			,'columns'				=> '2'
			,'pagination_loadmore'	=> '0'
			,'number_loadmore'		=> '8'
			,'is_slider'			=> '1'
			,'show_nav'				=> '1'
			,'auto_play'			=> '1'
			,'per_slide'			=> 3
			,'class'				=> ''

		), $atts));

		$columns_product 	= 'wd-columns-'.$columns;
		$class_slider		= '';
		if($is_slider == '1'){
			$columns_product = "";
			$class_slider	 = "wd-style-slider-product";
		}
		wp_reset_query();	

		// New Product
		$args = array(  
			'post_type' 		=> 'product',  
			'posts_per_page' 	=> $number_products,
			'orderby' 			=> $sort,
			'order'				=> $order_by,
			'paged' 			=> get_query_var('paged')
		);
		//Category
		if( $id_category != -1 ){
			$args['tax_query']= array(
					    	array(
							    	'taxonomy' 		=> 'product_cat',
									'terms' 		=> $id_category,
									'field' 		=> 'term_id',
									'operator' 		=> 'IN'
								)
			   			);
		}
		//Most View Products
		if($data_show == 'mostview_product'){
			$args['meta_key'] 	= '_wd_product_views_count';
			$args['orderby'] 	= 'meta_value_num';
			$args['order'] 		= 'DESC';
		}

		//On Sale Product
		if($data_show == 'onsale_product'){
			$args['meta_query'] = array(
					                    'relation' => 'OR',
					                    array( // Simple products type
					                        'key'           => '_sale_price',
					                        'value'         => 0,
					                        'compare'       => '>',
					                        'type'          => 'numeric'
					                    ),
					                    array( // Variable products type
					                        'key'           => '_min_variation_sale_price',
					                        'value'         => 0,
					                        'compare'       => '>',
					                        'type'          => 'numeric'
					                    )
	           					);
		}
		//Featured Product
		if($data_show == 'featured_product'){
			$args['meta_key'] 	= '_featured';
			$args['meta_value'] = 'yes';
		}

		$products 		= new WP_Query( $args );
		$count_products = $products->found_posts;
		$count 			= 0;
		$random_id 		= 'wd_special_product_slider'.mt_rand();	
		ob_start(); ?>
		<div class="wd-shortcode-product-slider-wrapper <?php esc_html_e($class); ?>">
			<?php if($title != "") : ?>
				<h2 class="wd-title-shortcode"><?php echo esc_attr($title); ?></div>
			<?php endif; ?>
			<div id="<?php echo esc_attr( $random_id ); ?>" class='wd-shortcode-product-slider <?php esc_html_e($class_slider); ?> wd-wrapper-parents-value'>
			<?php if ( $products->have_posts() ) : ?>
				<div class="wd-products-wrapper <?php esc_html_e($columns_product); ?>">
					<?php if ( $is_slider == '0') : ?>
						<ul class="products grid_default">
					<?php endif; ?>
					
					<!-- Begin while -->
					<?php while ( $products->have_posts() ) : $products->the_post();  ?>
						<?php if (($count == 0 || $count % $per_slide == 0) && $is_slider == '1') : ?>
							<div class="widget_per_slide">
								<ul class="products grid_default">
						<?php endif; // Endif ?>
						
								<?php wc_get_template_part( 'content', 'product' ); ?>
						
						<?php $count++; if( ($count % $per_slide == 0 || $count == $count_products) && $is_slider == '1' ): ?>
								</ul>
							</div>
						<?php endif; // Endif ?>
					<?php endwhile;	?>
					<!-- End While -->
					
					<?php if ( $is_slider == '0') : ?>
						</ul>
					<?php endif; ?>
				</div>
				<?php if( $show_nav && $is_slider ){ ?>
					<div class="slider_control">
						<a href="#" class="prev">&lt;</a>
						<a href="#" class="next">&gt;</a>
					</div>
				<?php } ?>
				<?php if($pagination_loadmore == '1') : ?> 
					<div class="wd-loadmore">
						<div style="display: none;" id="show_image_loading">
							<img src="<?php echo SC_IMAGE.'/ajax-loader_image.gif';?>" alt="HTML5 Icon" style="height:15px;">
						</div>

						<div id="loadmore">
							<a href="#" class="button btn_loadmore_product"><?php _e('LOAD MORE','wpdance') ?></a>
						</div>
					</div>
					<div class="hidden">
						<input type="text" value="<?php esc_html_e($number_loadmore); ?>" id="tvlgiao_number_loadmore">
						<input type="text" value="<?php esc_html_e($id_category); ?>" id="tvlgiao_id_category">	
						<input type="text" value="<?php esc_html_e($data_show); ?>" id="tvlgiao_data_show">
					</div>
				<?php endif; ?>
			<?php endif; // Have Product?>	
			</div>
		</div>
		<?php if ( $is_slider == '1') : ?>
			<script type="text/javascript">
				jQuery(document).ready(function(){
					"use strict";						
					var $_this = jQuery('#<?php echo esc_attr( $random_id ); ?>');
					var _auto_play = <?php echo esc_attr( $auto_play ); ?> == 1;
					var owl = $_this.find('.wd-products-wrapper').owlCarousel({
								loop : true
								,items : 1
								,nav : false
								,dots : false
								,navSpeed : 1000
								,slideBy: 1
								,rtl:jQuery('body').hasClass('rtl')
								,navRewind: false
								,autoplay: _auto_play
								,autoplayTimeout: 5000
								,autoplayHoverPause: true
								,autoplaySpeed: false
								,mouseDrag: true
								,touchDrag: true
								,responsiveBaseElement: $_this
								,responsiveRefreshRate: 1000
								,responsive:{
									0:{
										items : 1
									},
									300:{
										items : 1
									},
									579:{
										items : <?php if($columns == 5){echo $columns - 2;}elseif($columns == 4){echo $columns;}elseif($columns==3){echo $columns - 1;}else{echo $columns;}  ?>
									},
									767:{
										items : <?php if($columns == 5){echo $columns - 1;}elseif($columns == 4){echo $columns;}elseif($columns==3){echo $columns;}else{echo $columns;}  ?>
									},
									1100:{
										items : <?php echo $columns ?>
									}
								}
								
								,onInitialized: function(){
								}
							});
							$_this.on('click', '.next', function(e){
								e.preventDefault();
								owl.trigger('next.owl.carousel');
							});

							$_this.on('click', '.prev', function(e){
								e.preventDefault();
								owl.trigger('prev.owl.carousel');
							});
				});
			</script>
		<?php endif; // Endif Slider?>
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		wp_reset_postdata();
		return $content;
	}
}
add_shortcode('tvlgiao_wpdance_special_products_slider', 'tvlgiao_wpdance_special_products_slider_function');
?>